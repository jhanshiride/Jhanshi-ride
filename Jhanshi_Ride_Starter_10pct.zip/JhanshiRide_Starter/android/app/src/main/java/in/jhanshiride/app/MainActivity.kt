package in.jhanshiride.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JhanshiRideApp() }
    }
}

@Composable
fun JhanshiRideApp() {
    var mode by remember { mutableStateOf("Customer") }
    var vehicle by remember { mutableStateOf("Bike") }
    var pickup by remember { mutableStateOf("Jhansi Railway Station") }
    var drop by remember { mutableStateOf("Jhansi Bus Stand") }
    var payment by remember { mutableStateOf("Cash") }
    var message by remember { mutableStateOf("अपनी पहली राइड बुक करें") }
    var fare by remember { mutableStateOf(100.0) }
    val commission = fare * 0.10
    val driverEarning = fare - commission

    MaterialTheme {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("JHANSHI RIDE", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                Text("Apna Shehar, Apni Ride", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = mode == "Customer", onClick = { mode = "Customer" }, label = { Text("Customer") })
                    FilterChip(selected = mode == "Driver", onClick = { mode = "Driver" }, label = { Text("Driver") })
                }
                HorizontalDivider()
                if (mode == "Customer") {
                    Text("Book a ride", style = MaterialTheme.typography.titleLarge)
                    Text("Vehicle type")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Bike", "Auto", "Car").forEach {
                            FilterChip(selected = vehicle == it, onClick = { vehicle = it }, label = { Text(it) })
                        }
                    }
                    OutlinedTextField(value = pickup, onValueChange = { pickup = it }, label = { Text("Pickup location") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = drop, onValueChange = { drop = it }, label = { Text("Drop location") }, modifier = Modifier.fillMaxWidth())
                    Text("Payment method")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Cash", "UPI", "Online").forEach {
                            FilterChip(selected = payment == it, onClick = { payment = it }, label = { Text(it) })
                        }
                    }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Demo fare", fontWeight = FontWeight.Bold)
                            Text("₹${"%.0f".format(fare)}")
                            Text("Final fare server fare rules se aayega.")
                        }
                    }
                    Button(onClick = { message = "$vehicle request demo: $pickup → $drop. Backend integration pending." }, modifier = Modifier.fillMaxWidth()) {
                        Text("Find a ride")
                    }
                } else {
                    Text("Driver dashboard", style = MaterialTheme.typography.titleLarge)
                    Text("Driver status: Offline (demo)")
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Driver earning calculator", fontWeight = FontWeight.Bold)
                            Text("Ride fare: ₹${"%.2f".format(fare)}")
                            Text("Jhanshi Ride commission (10%): ₹${"%.2f".format(commission)}")
                            Text("Your earning (90%): ₹${"%.2f".format(driverEarning)}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            Slider(value = fare.toFloat(), onValueChange = { fare = it.toDouble() }, valueRange = 50f..2000f)
                        }
                    }
                    Button(onClick = { message = "Driver online status demo. KYC approval required before real rides." }, modifier = Modifier.fillMaxWidth()) { Text("Go Online") }
                    OutlinedButton(onClick = { message = "No live ride assigned yet." }, modifier = Modifier.fillMaxWidth()) { Text("Check ride requests") }
                    Text("KYC: Driving Licence • RC • Insurance • Permit • Profile verification")
                }
                Text(message, color = MaterialTheme.colorScheme.primary)
                Text("Demo starter only — real booking, maps, OTP and payments are not connected.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
