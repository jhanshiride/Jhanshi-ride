const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
app.use(cors());
app.use(express.json());

const rides = new Map(); // Demo memory store only. Replace with PostgreSQL.
const PLATFORM_RATE = 0.10;
const roundMoney = n => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

function splitFare(fare) {
  const totalFare = roundMoney(fare);
  const platformCommission = roundMoney(totalFare * PLATFORM_RATE);
  const driverEarning = roundMoney(totalFare - platformCommission);
  return { totalFare, commissionRate: 10, platformCommission, driverEarning };
}

app.get('/health', (_req, res) => res.json({ ok: true, app: 'Jhanshi Ride API', version: '0.2.0' }));

app.post('/api/fare/quote', (req, res) => {
  const { vehicle, distanceKm } = req.body || {};
  const rates = { Bike: { base: 25, perKm: 8 }, Auto: { base: 35, perKm: 12 }, Car: { base: 60, perKm: 16 } };
  if (!rates[vehicle] || !Number.isFinite(Number(distanceKm)) || Number(distanceKm) <= 0) {
    return res.status(400).json({ error: 'Valid vehicle and positive distanceKm are required' });
  }
  const fare = roundMoney(rates[vehicle].base + rates[vehicle].perKm * Number(distanceKm));
  res.json({ vehicle, distanceKm: Number(distanceKm), ...splitFare(fare), note: 'Demo rates only; configure approved local fares before launch.' });
});

app.post('/api/rides', (req, res) => {
  const { riderName, vehicle, pickup, drop, payment, fare } = req.body || {};
  if (!vehicle || !['Bike', 'Auto', 'Car'].includes(vehicle) || !pickup || !drop) {
    return res.status(400).json({ error: 'vehicle, pickup and drop are required' });
  }
  if (!Number.isFinite(Number(fare)) || Number(fare) <= 0) {
    return res.status(400).json({ error: 'A valid quoted fare is required' });
  }
  const id = `JR${Date.now()}`;
  const ride = { id, riderName: riderName || 'Guest', vehicle, pickup, drop,
    payment: payment || 'Cash', status: 'SEARCHING', createdAt: new Date().toISOString(),
    ...splitFare(fare), payoutStatus: 'PENDING' };
  rides.set(id, ride);
  io.emit('ride:new', ride);
  res.status(201).json(ride);
});

app.get('/api/rides', (_req, res) => res.json([...rides.values()]));

app.post('/api/rides/:id/accept', (req, res) => {
  const ride = rides.get(req.params.id);
  if (!ride) return res.status(404).json({ error: 'Ride not found' });
  if (ride.status !== 'SEARCHING') return res.status(409).json({ error: 'Ride is no longer available' });
  ride.driverId = req.body.driverId || 'demo-driver';
  ride.status = 'ACCEPTED';
  io.emit('ride:updated', ride);
  res.json(ride);
});

app.post('/api/rides/:id/status', (req, res) => {
  const ride = rides.get(req.params.id);
  const allowed = ['ARRIVED', 'STARTED', 'COMPLETED', 'CANCELLED'];
  if (!ride) return res.status(404).json({ error: 'Ride not found' });
  if (!allowed.includes(req.body.status)) return res.status(400).json({ error: 'Invalid status' });
  ride.status = req.body.status;
  if (ride.status === 'COMPLETED') {
    ride.completedAt = new Date().toISOString();
    ride.payoutStatus = ride.payment === 'Cash' ? 'CASH_COLLECTION_DUE' : 'GATEWAY_RECONCILIATION_PENDING';
  }
  io.emit('ride:updated', ride);
  res.json(ride);
});

app.get('/api/admin/summary', (_req, res) => {
  const all = [...rides.values()];
  const completed = all.filter(r => r.status === 'COMPLETED');
  res.json({
    totalRides: all.length,
    completedRides: completed.length,
    grossFare: roundMoney(completed.reduce((s, r) => s + r.totalFare, 0)),
    platformCommission: roundMoney(completed.reduce((s, r) => s + r.platformCommission, 0)),
    driverEarnings: roundMoney(completed.reduce((s, r) => s + r.driverEarning, 0)),
    commissionRate: 10
  });
});

io.on('connection', socket => {
  socket.emit('server:hello', { app: 'Jhanshi Ride', message: 'Connected to demo realtime server' });
});
const port = process.env.PORT || 4000;
server.listen(port, () => console.log(`Jhanshi Ride API listening on ${port}`));
