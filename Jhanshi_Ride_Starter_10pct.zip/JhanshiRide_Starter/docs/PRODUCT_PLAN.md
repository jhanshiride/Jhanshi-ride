# Jhanshi Ride — Product Plan

## Roles
- Rider: phone OTP, pickup/drop, Bike/Auto/Car, fare estimate, booking, live trip, cash/UPI/online, trip history, rating, SOS/support.
- Driver: onboarding, KYC approval, vehicle documents, online/offline, accept/reject, navigation, start/end OTP, earnings, payout history.
- Admin: dashboard, approve/suspend drivers, vehicle/document review, fare configuration, trips, refunds/complaints, commissions, service zones, reports.

## Suggested architecture
- Android: Kotlin + Jetpack Compose; one app module can be split into Rider and Driver apps before launch.
- Backend: Node.js + Express + Socket.IO.
- Production database: PostgreSQL + PostGIS for nearby-driver queries; Redis for presence/dispatch.
- Maps: Google Maps Platform or Mapbox.
- OTP: compliant SMS provider.
- Payments: RBI-compliant payment gateway integration; never store card/UPI PIN credentials.
- Notifications: Firebase Cloud Messaging.
- Admin: React/Next.js + role-based access control.

## Dispatch flow
1. Rider sends pickup/drop and vehicle category.
2. Server calculates quote using admin-configured base fare, per-km, per-minute, minimum fare, waiting and taxes.
3. Server finds eligible online, approved drivers nearby.
4. Driver accepts; server atomically assigns one driver.
5. Driver location streams only during active trip.
6. Start/end OTP and trip state are validated server-side.
7. Payment is reconciled via gateway webhook or driver cash confirmation.

## Launch gates
- Confirm current UP/Jhansi rules for each vehicle category and aggregator operation.
- Verify permits, commercial registration, insurance, fitness, driving licence, PUC and driver identity.
- Publish terms, privacy policy, cancellation/refund policy and grievance contact.
- Security review, load testing, emergency workflow and support staffing.
