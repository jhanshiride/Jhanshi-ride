# Jhanshi Ride — शुरुआती MVP

यह एक **starter source project** है, तैयार/प्रोडक्शन APK नहीं।

## इसमें क्या है
- `android/`: Kotlin + Jetpack Compose Android starter (Customer/Driver mode switch और booking UI)
- `backend/`: Node.js + Express + Socket.IO starter API (demo ride create/accept/status + realtime event)
- `admin/`: शुरुआती Admin dashboard HTML
- `docs/`: आगे के निर्माण की योजना

## जरूरी बातें
1. अभी किराया demo calculation है; लॉन्च से पहले Jhansi के वास्तविक किराये/नियम तय करें।
2. Live map के लिए Google Maps/Mapbox API key, location permission और background-location compliance चाहिए।
3. Online payment के लिए Razorpay/अन्य payment gateway merchant account, server-side order creation और webhook verification चाहिए। अभी online payment वास्तविक रूप से charge नहीं करता।
4. Driver KYC, DL, RC, insurance, permit, police verification, customer support और applicable UP/Uttar Pradesh aggregator / bike-taxi नियमों की कानूनी जाँच जरूरी है।
5. Production में database (PostgreSQL), authentication (OTP), secure admin login, audit logs, rate limiting, HTTPS, backups और privacy policy जोड़ें।

## चलाने का तरीका (कंप्यूटर/क्लाउड build environment आवश्यक)
### Backend
```bash
cd backend
npm install
npm start
```
Server default `http://localhost:4000` पर चलेगा। Health: `/health`

### Android
Android Studio में `android/` खोलें और Gradle sync करके Run करें।
Emulator से backend के लिए `10.0.2.2:4000` उपयोग करें। असली फोन पर `BASE_URL` को आपके कंप्यूटर/सर्वर के LAN IP या hosted HTTPS URL से बदलें।

### Admin
`admin/index.html` ब्राउज़र में खोलें। यह demo dashboard है; secure production admin नहीं।

## MVP चरण
1. Customer/Driver UI और basic booking
2. OTP login + driver KYC
3. Real map, fare rules, driver matching
4. Payment gateway + receipts/refunds
5. Admin controls, support, analytics
6. Closed pilot in Jhansi, safety/legal checks, then public launch


## 10% कमीशन मॉडल (नया)
हर पूरी हुई राइड के किराये का 10% Jhanshi Ride platform commission और 90% driver earning होगा।
उदाहरण: ₹200 किराया → ₹20 platform commission + ₹180 driver earning.
API:
- `POST /api/fare/quote` body: `{ "vehicle":"Bike", "distanceKm":5 }`
- `POST /api/rides` में quoted `fare` भेजना जरूरी है।
- `GET /api/admin/summary` से कुल gross fare, platform commission और driver earnings मिलेंगे।
यह starter demo memory में data रखता है; server restart पर data मिट जाएगा। Production में database और payment reconciliation जरूरी है।
